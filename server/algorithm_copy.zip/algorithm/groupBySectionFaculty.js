function groupBySectionFaculty(rows) {
    const grouped = {};

    rows.forEach(row => {
        if (!grouped[row.subject_id]) {
            grouped[row.subject_id] = {
                subject_id: row.subject_id,
                name: row.name,
                type: row.type,
                semester_id: row.semester_id,
                hours_per_week: row.hours_per_week,
                faculty_list: []  // Store section-faculty mappings
            };
        }

        grouped[row.subject_id].faculty_list.push({
            faculty_id: row.faculty_id,
            section_id: row.section_id
        });
    });

    // Flatten the grouped object to return an array of section-faculty mappings
    return Object.values(grouped).flatMap(group => 
        group.faculty_list.map(entry => ({
            subject_id: group.subject_id,
            name: group.name,
            type: group.type,
            semester_id: group.semester_id,
            hours_per_week: group.hours_per_week,
            faculty_id: entry.faculty_id,
            section_id: entry.section_id
        }))
    );
}

export default groupBySectionFaculty;